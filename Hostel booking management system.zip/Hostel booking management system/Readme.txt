How to run Project
1. Download and Unzip the file on your local system copy hostel .
2. Put hostel folder inside root directory (for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

Database Configuration

Open phpmyadmin
Create Database hostel_db
Import database hostel_db.sql (available SQL File Folder inside zip package)

For User
Open Your browser put inside browser “http://localhost/hostel”
Login Details for user:
Email : john@gmail.com
Password: 123

For Admin Panel
Open Your browser put inside browser “http://localhost/hostel/admin”
Login Details for admin :
Username: admin
Password: 1234

This project is free to use both personal and commercial

For commercial use, we recommend to first contact us to give support, improve on security and to add more useful functionalities

All our services are free don't fear to contact us on code4berryteam@gmail.com