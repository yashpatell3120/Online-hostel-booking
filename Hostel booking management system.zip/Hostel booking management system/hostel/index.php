<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Hostel Booking - Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Book hostels online easily with our platform.">
    <meta name="author" content="Your Name">

    <!-- CSS -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="materialize/css/materialize.min.css" media="screen,projection">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
    <link href="css/flexslider.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/zoomslider.css">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
<div id="wrapper" class="home-page">

    <!-- Header -->
    <?php include('includes/header.php') ?>
    <!-- End Header -->

    <!-- Banner Section -->
    <section id="banner">
        <!-- Slider -->
        <div id="slider" data-zs-src='["img/bg_7.jpg", "img/bg_2.jpg", "img/bg_8.jpg"]'></div>
        <!-- End Slider -->
    </section>
    <!-- End Banner Section -->

    <!-- Featured Hostels Section -->
    <section class="projects">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="aligncenter">
                        <h2 class="aligncenter">Featured Hostels</h2>
                        <p>Discover amazing hostels for your next adventure, in the midst of tranquelity. the lushyously green campus of ADIT new vidya nagar welcomes you.</p>
                    </div>
                </div>
            </div>

            <div class="row service-v1 margin-bottom-40">
                <!-- Hostel 1 -->
                <div class="col-md-4 md-margin-bottom-40">
                    <div class="card small">
                        <div class="card-image">
                            <img class="img-responsive" src="img/adit3.jpg" alt="Hostel 1">
                        </div>
                        <div class="card-content">
                            <h4>ADIT Hostel</h4>
                            <h5>Location: ADIT ANAND</h5>
                            <a href="hosteluser" class="btn btn-details">Book Now</a>
                        </div>
                    </div>
                </div>
                <!-- Hostel 2 -->
                <div class="col-md-4 md-margin-bottom-40">
                    <div class="card small">
                        <div class="card-image">
                            <img class="img-responsive" src="img/adit2.jpg" alt="Hostel 2">
                        </div>
                        <div class="card-content">
                            <h4>Kashyap Hostel</h4>
                            <h5>Location: ADIT ANAND</h5>
                            <a href="hosteluser" class="btn btn-details">Book Now</a>
                        </div>
                    </div>
                </div>
                <!-- Hostel 3 -->
                <div class="col-md-4 md-margin-bottom-40">
                    <div class="card small">
                        <div class="card-image">
                            <img class="img-responsive" src="img/adit1.jpg" alt="Hostel 3">
                        </div>
                        <div class="card-content">
                            <h4>Sharda Hostel</h4>
                            <h5>Location: ADIT ANAND</h5>
                            <a href="hosteluser" class="btn btn-details">Book Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Featured Hostels Section -->

    <!-- About Us Section -->
    <section class="section-padding gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title text-center">
                        <h2>About Us</h2>
                        <p>Welcome to our hostel booking platform. Find the perfect accommodation for your travels.we provide the best rooms at the most reasonable rates, with flexible contracts as per accommodation time. </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="about-image">
                        <img src="img/cvmu.jpg" alt="About Us Image">
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="about-text">
                        <h3>Our Mission</h3>
                        <p>We strive to make hostel booking easy and accessible for travelers worldwide. With our platform, you can find and book hostels in your desired location hassle-free.</p>
                        <a href="about.php" class="btn btn-primary waves-effect waves-dark">Learn More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End About Us Section -->

    <!-- Footer -->
    <?php include('includes/footer.php') ?>
    <!-- End Footer -->

</div>
<a href="#" class="scrollup waves-effect waves-dark"><i class="fa fa-angle-up HillSide"></i></a>

<!-- Scripts -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="materialize/js/materialize.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.zoomslider.min.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>
