 <nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">

        <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
            </a>
        </li>
        

        <li class="nav-item">
            <a class="nav-link" href="student_register.php">
                <span class="menu-title">Book Hostel</span>
                <i class="mdi mdi-book menu-icon"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="student_details.php">
                <span class="menu-title">Room Details</span>
                <i class="mdi mdi-bank menu-icon"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="profile.php">
                <span class="menu-title">My Profile</span>
                <i class="mdi mdi-account menu-icon"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="change_password.php">
                <span class="menu-title">Change Password</span>
                <i class="mdi mdi-lock menu-icon"></i>
            </a>
        </li>
    </ul>
</nav>