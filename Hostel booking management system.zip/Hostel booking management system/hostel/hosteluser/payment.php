<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Payment Details</h3>
                    </div>
                    <div class="card-body">
                        <form id="paymentForm" action="#" method="POST">
                            <div class="form-group">
                                <label for="name">Cardholder Name</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter Cardholder Name" required>
                            </div>
                            <div class="form-group">
                                <label for="cardNumber">Card Number</label>
                                <input type="text" class="form-control" id="cardNumber" name="cardNumber" placeholder="Enter Card Number" required>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="expiry">Expiry Date</label>
                                    <input type="text" class="form-control" id="expiry" name="expiry" placeholder="MM/YY" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="cvv">CVV</label>
                                    <input type="text" class="form-control" id="cvv" name="cvv" placeholder="CVV" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Make Payment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Add event listener for form submission
        document.getElementById("paymentForm").addEventListener("submit", function(event) {
            // Prevent default form submission
            event.preventDefault();
            
            // Simulate payment processing (here you can add actual payment processing logic)
            setTimeout(function() {
                // Redirect user back to registration page after successful payment
                window.location.href = "student_register.php";
            }, 2000); // Delay added for demonstration, you can remove this in actual implementation
        });
    </script>
</body>
</html>
